create database staff_user_creation;
use staff_user_creation;
create table user_information(
 First_Name varchar(255),
 Last_Name varchar(255),
 Display_Name varchar(255),
 Login_Email varchar(255),
 Email varchar(255),
 Alternative_Email varchar(255),
 Phone_Home int,
 phone_Work int,
 Mobile int,
 Reporting_Manager varchar(255),
 Status varchar(255)
);

create table Assigned_Role(
Recruiter varchar(250),
Bdm varchar(250),
Admin varchar(250)
);

create database Client_Creation;
use Client_Creation;
create table Client_Information(
Company_Name varchar(255),
Company_Website varchar(255),
Select_Industry_Type varchar(255),
Select_Employee_Strength varchar(255),
Login_Email varchar(255),
Alternate_Email varchar(255),
Select_Country varchar(255),
Select_State varchar(255),
Select_City varchar(255),
Street varchar(255),
Zip_Code int,
Phone_Number int,
Alternate_Phone int,
Fax varchar(255)
);
create table Assign_Client_to_BDM(
BDM varchar(255)
);

create database Add_Contact_to_the_client;
use Add_Contact_to_the_client;
create table Add_Contact(
Comapany_Name varchar(255),
First_Name varchar(255),
Last_Name varchar(255),
Display_Name varchar(255),
Email varchar(255),
Alternate_Email varchar(255),
Mobile int,
Phone_Home int
);

create database Add_New_Opening;
use Add_New_Opening;
create table Company_Information(
Company_Name varchar(255),
Contact_Name varchar(255)
);
create table Opening_Information(
Opening_Title varchar(255),
Requried_Skills varchar(255),
Experience_Level INTEGER,
Required_Experience INTEGER,
Salary_Range integer,
Currency varchar(255),
Pay_Type varchar(255),
Country varchar(255),
State varchar(255),
City varchar(255),
Zip_Code Integer,
Number_Of_Openings int,
Max_Resumes_Allowed int,
Local_indicator varchar(255),
Security_Clearance varchar(255),
Short_Discription varchar(255)
);
ALTER table Opening_Information add Job_Discription varchar(255);
 select * from Opening_Information;
 
 Create table Duration_Type(
 Duration_Month int,
 Category varchar(255),
 SubCategory varchar(255),
 Employment_Type varchar(255),
 Status varchar(255),
 Interview_Type varchar(255),
 Visa_Type varchar(255),
 Project_Start_Date date,
 Project_End_Date date
 );
 